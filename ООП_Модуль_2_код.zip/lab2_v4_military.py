class MilitaryStaff:
    """Родитель: общие данные военнослужащего."""

    def __init__(self, surname, company, rank, birthDate,
                 serviceStartDate, unit):
        self.surname = surname                    # фамилия
        self.company = company                    # рота
        self.rank = rank                          # звание
        self.birthDate = birthDate                # дата рождения
        self.serviceStartDate = serviceStartDate  # дата поступления на службу
        self.unit = unit                          # часть

    def showInfo(self):
        print('Фамилия:', self.surname, '| Рота:', self.company,
              '| Звание:', self.rank)
        print('Дата рождения:', self.birthDate,
              '| На службе с:', self.serviceStartDate,
              '| Часть:', self.unit)


class CommandBody(MilitaryStaff):
    """Органы военного управления."""

    def __init__(self, surname, company, rank, birthDate,
                 serviceStartDate, unit, districtName, position,
                 yearsOfService, allowance):
        super().__init__(surname, company, rank, birthDate,
                         serviceStartDate, unit)
        self.districtName = districtName          # название округа
        self.position = position                  # должность
        self.yearsOfService = yearsOfService      # выслуга лет
        self.allowance = allowance                # сумма надбавки

    def showInfo(self):
        print('Органы военного управления:')
        super().showInfo()
        print('Округ:', self.districtName, '| Должность:', self.position)
        print('Выслуга лет:', self.yearsOfService,
              '| Надбавка:', self.allowance)


class ContractService(MilitaryStaff):
    """Военная служба по контракту."""

    def __init__(self, surname, company, rank, birthDate,
                 serviceStartDate, unit, contractPeriod, contractDate,
                 protocolNumber, salary):
        super().__init__(surname, company, rank, birthDate,
                         serviceStartDate, unit)
        self.contractPeriod = contractPeriod      # период договора
        self.contractDate = contractDate          # дата договора
        self.protocolNumber = protocolNumber      # номер протокола
        self.salary = salary                      # сумма зарплаты

    def showInfo(self):
        print('Военная служба по контракту:')
        super().showInfo()
        print('Период договора:', self.contractPeriod,
              '| Дата договора:', self.contractDate)
        print('Номер протокола:', self.protocolNumber,
              '| Зарплата:', self.salary)


class Awarded(MilitaryStaff):
    """Награждённые."""

    def __init__(self, surname, company, rank, birthDate,
                 serviceStartDate, unit, awardName, bonus, allowance):
        super().__init__(surname, company, rank, birthDate,
                         serviceStartDate, unit)
        self.awardName = awardName                # название награды
        self.bonus = bonus                        # премия
        self.allowance = allowance                # сумма надбавки

    def showInfo(self):
        print('Награждённые:')
        super().showInfo()
        print('Награда:', self.awardName)
        print('Премия:', self.bonus, '| Надбавка:', self.allowance)


class MilitaryList:
    """Хранилище списка военнослужащих."""

    def __init__(self):
        self.people = []

    def addPerson(self, person):
        self.people.append(person)

    def showList(self):
        print('Список военнослужащих (всего:', len(self.people), ')')
        for number, person in enumerate(self.people, start=1):
            print('-' * 60)
            print('№', number)
            person.showInfo()


staff = MilitaryList()
staff.addPerson(CommandBody('Иванов', '1-я рота', 'майор', '12.03.1985',
                            '01.09.2007', 'в/ч 12345', 'Северный округ',
                            'начальник штаба', 19, 45000))
staff.addPerson(ContractService('Петров', '2-я рота', 'сержант',
                                '25.07.1996', '15.08.2018', 'в/ч 12345',
                                '3 года', '15.08.2024', 'ПР-0147', 210000))
staff.addPerson(ContractService('Ахметов', '2-я рота', 'рядовой',
                                '09.01.2001', '10.09.2023', 'в/ч 12345',
                                '2 года', '10.09.2023', 'ПР-0215', 175000))
staff.addPerson(Awarded('Сидоров', '3-я рота', 'капитан', '02.11.1990',
                        '01.07.2012', 'в/ч 67890',
                        'медаль «За безупречную службу»', 100000, 20000))
staff.showList()
