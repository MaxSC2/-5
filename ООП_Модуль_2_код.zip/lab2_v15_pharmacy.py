class Pharmacy:
    """Родитель: общие данные аптеки."""

    def __init__(self, name, address, city, director):
        self.name = name              # название аптеки
        self.address = address        # адрес
        self.city = city              # город
        self.director = director      # ФИО директора

    def showInfo(self):
        print('Аптека:', self.name, '| Город:', self.city)
        print('Адрес:', self.address, '| Директор:', self.director)


class PharmacyClient(Pharmacy):
    """Клиенты аптеки."""

    def __init__(self, name, address, city, director, lastName,
                 firstName, patronymic, discountPercent):
        super().__init__(name, address, city, director)
        self.lastName = lastName                  # фамилия клиента
        self.firstName = firstName                # имя клиента
        self.patronymic = patronymic              # отчество клиента
        self.discountPercent = discountPercent    # процент скидки

    def showInfo(self):
        print('Клиент аптеки:')
        super().showInfo()
        print('Клиент:', self.lastName, self.firstName, self.patronymic)
        print('Скидка, %:', self.discountPercent)


class MedicineStock(Pharmacy):
    """Лекарственный фонд аптеки."""

    def __init__(self, name, address, city, director, medicineName,
                 medicineType, price, country):
        super().__init__(name, address, city, director)
        self.medicineName = medicineName          # название лекарства
        self.medicineType = medicineType          # тип лекарства
        self.price = price                        # цена лекарства
        self.country = country                    # страна-производитель

    def showInfo(self):
        print('Лекарственный фонд:')
        super().showInfo()
        print('Лекарство:', self.medicineName, '| Тип:', self.medicineType)
        print('Цена:', self.price, '| Страна:', self.country)


class Sale(Pharmacy):
    """Продажа лекарства клиенту."""

    def __init__(self, name, address, city, director, medicineName,
                 price, clientName, quantity):
        super().__init__(name, address, city, director)
        self.medicineName = medicineName          # название лекарства
        self.price = price                        # цена лекарства
        self.clientName = clientName              # ФИО клиента
        self.quantity = quantity                  # количество
        self.total = price * quantity             # сумма к оплате

    def showInfo(self):
        print('Продажа:')
        super().showInfo()
        print('Лекарство:', self.medicineName, '| Цена:', self.price)
        print('Клиент:', self.clientName, '| Количество:', self.quantity)
        print('Сумма к оплате:', self.total)


class PharmacyList:
    """Хранилище записей аптеки: клиенты, лекарства, продажи."""

    def __init__(self):
        self.items = []

    def addItem(self, item):
        self.items.append(item)

    def showList(self):
        print('Список записей аптеки (всего:', len(self.items), ')')
        for number, item in enumerate(self.items, start=1):
            print('-' * 60)
            print('№', number)
            item.showInfo()


base = ('Аптека №5', 'ул. Конституции, 12', 'Петропавловск',
        'Смирнова О. П.')
storage = PharmacyList()
storage.addItem(PharmacyClient(*base, 'Ким', 'Алина', 'Сергеевна', 10))
storage.addItem(MedicineStock(*base, 'Парацетамол 500 мг', 'таблетки',
                              350, 'Казахстан'))
storage.addItem(MedicineStock(*base, 'Ибупрофен 200 мг', 'капсулы',
                              780, 'Германия'))
storage.addItem(Sale(*base, 'Парацетамол 500 мг', 350, 'Ким А. С.', 3))
storage.showList()
