class TouristTrip:
    """Туристический тур."""

    def __init__(self, tourName, countries, cities, transportType,
                 mealType, price, accommodationType, departureDate):
        self.tourName = tourName                    # название тура
        self.countries = countries                  # страны
        self.cities = cities                        # города
        self.transportType = transportType          # тип передвижения
        self.mealType = mealType                    # тип питания
        self.price = price                          # цена тура
        self.accommodationType = accommodationType  # тип проживания
        self.departureDate = departureDate          # дата выезда
        print('Сработал конструктор:', self.tourName)

    def __del__(self):
        print('Сработал деструктор:', self.tourName)

    def printData(self):
        print('Информация о туре')
        print('Название тура =', self.tourName)
        print('Страны =', self.countries)
        print('Города =', self.cities)
        print('Тип передвижения =', self.transportType)
        print('Тип питания =', self.mealType)
        print('Цена тура =', self.price)
        print('Тип проживания =', self.accommodationType)
        print('Дата выезда =', self.departureDate)


europe = TouristTrip('Города Европы', 'Германия, Чехия', 'Берлин, Прага',
                     'автобус', 'завтраки', 450000, 'отель 3*',
                     '15.06.2026')
turkey = TouristTrip('Море в Турции', 'Турция', 'Анталья', 'самолёт',
                     'всё включено', 620000, 'отель 5*', '01.07.2026')
europe.printData()

# Динамический атрибут класса
TouristTrip.currency = 'тенге'
print('TouristTrip.currency =', TouristTrip.currency)
print('europe.currency =', europe.currency)
print('turkey.currency =', turkey.currency)

# Динамический атрибут экземпляра
europe.guide = 'Нурлан С.'
print('europe.guide =', europe.guide)
print('У turkey есть guide?', hasattr(turkey, 'guide'))

# Работа деструктора
del europe
alias = turkey
del turkey
print('Имя turkey удалено, но ссылка alias ещё есть')
del alias
print('Конец программы')
