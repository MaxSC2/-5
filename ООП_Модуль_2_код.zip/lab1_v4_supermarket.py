class Supermarket:
    """Товар, который продаётся в отделе супермаркета."""

    def __init__(self, nameotdela, productCode, name, country,
                 retailPrice, namesource):
        self.nameotdela = nameotdela      # название отдела
        self.productCode = productCode    # код товара
        self.name = name                  # наименование товара
        self.country = country            # страна-производитель
        self.retailPrice = retailPrice    # розничная цена
        self.namesource = namesource      # поставщик
        print('Сработал конструктор:', self.name)

    def __del__(self):
        print('Сработал деструктор:', self.name)

    def printData(self):
        print('Информация о товаре')
        print('Отдел =', self.nameotdela)
        print('Код товара =', self.productCode)
        print('Наименование =', self.name)
        print('Страна-производитель =', self.country)
        print('Розничная цена =', self.retailPrice)
        print('Поставщик =', self.namesource)


milk = Supermarket('Молочный отдел', 'M-1001', 'Молоко 3,2%',
                   'Казахстан', 480, 'ТОО «Агро-Север»')
bread = Supermarket('Хлебный отдел', 'B-2005', 'Хлеб ржаной',
                    'Россия', 190, 'ИП Ковалёв')
milk.printData()

# Динамический атрибут класса: доступен всем экземплярам
Supermarket.currency = 'тенге'
print('Supermarket.currency =', Supermarket.currency)
print('milk.currency =', milk.currency)
print('bread.currency =', bread.currency)

# Динамический атрибут экземпляра: есть только у одного объекта
milk.discount = 10
print('milk.discount =', milk.discount)
print('У bread есть discount?', hasattr(bread, 'discount'))

# Работа деструктора
del milk                 # единственная ссылка удалена
alias = bread            # вторая ссылка на тот же объект
del bread
print('Имя bread удалено, но ссылка alias ещё есть')
del alias                # ссылок не осталось
print('Конец программы')
